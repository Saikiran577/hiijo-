package net.codejava;
import...
@SpringBootApplication

public class Appmain {
    public static void main(String[] args) {
        SpringApplication.run(Appmain.class, args);
    }
}
