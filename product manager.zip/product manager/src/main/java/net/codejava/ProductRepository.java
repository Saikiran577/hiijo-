package net.codejava;
import org.springframework.data.jpa.repository.jparepository;

public interface  ProductRepository extends JpaRepository<Product, Long> {
}
